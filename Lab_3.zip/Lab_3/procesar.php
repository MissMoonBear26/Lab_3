<?php
include 'includes/header.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit();
}

$errores = [];

$nombreRaw = isset($_POST['nombre']) ? $_POST['nombre'] : '';
$apellidoRaw = isset($_POST['apellido']) ? $_POST['apellido'] : '';
$identificacionRaw = isset($_POST['identificacion']) ? $_POST['identificacion'] : '';
$fechaNacimiento = isset($_POST['fecha_nacimiento']) ? $_POST['fecha_nacimiento'] : '';
$sexoRaw = isset($_POST['sexo']) ? $_POST['sexo'] : '';

$nombreLimpio = htmlspecialchars(strip_tags(trim($nombreRaw)));
$apellidoLimpio = htmlspecialchars(strip_tags(trim($apellidoRaw)));
$identificacionLimpia = htmlspecialchars(strip_tags(trim($identificacionRaw)));
$sexoLimpio = htmlspecialchars(strip_tags(trim($sexoRaw)));

$nombre = ucwords(strtolower($nombreLimpio));
$apellido = ucwords(strtolower($apellidoLimpio));
$identificacion = strtoupper($identificacionLimpia);

$edad = 0;
if (!empty($fechaNacimiento)) {
    $fechaNac = new DateTime($fechaNacimiento);
    $hoy = new DateTime();
    $edad = $hoy->diff($fechaNac)->y;

    if ($edad < 18 || $edad > 70) {
        $errores[] = "La edad del aspirante debe estar en el rango de 18 a 70 años. Edad calculada: $edad años.";
    }
} else {
    $errores[] = "Debe ingresar una fecha de nacimiento válida.";
}

$rutaImagenServidor = "";
if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
    $nombreArchivo = $_FILES['foto']['name'];
    $tmpArchivo = $_FILES['foto']['tmp_name'];
    
    $extension = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));
    $extensionesPermitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    if (in_array($extension, $extensionesPermitidas)) {
        $nuevoNombre = uniqid('aspirante_', true) . '.' . $extension;
        $directorioDestino = 'uploaded_files/';

        if (!is_dir($directorioDestino)) {
            mkdir($directorioDestino, 0755, true);
        }

        $rutaFinal = $directorioDestino . $nuevoNombre;

        if (move_uploaded_file($tmpArchivo, $rutaFinal)) {
            $rutaImagenServidor = $rutaFinal;
        } else {
            $errores[] = "Error al guardar la fotografía en el servidor.";
        }
    } else {
        $errores[] = "Formato de imagen no permitido. Extensión cargada: .$extension. Tipos válidos: " . implode(', ', $extensionesPermitidas);
    }
} else {
    $errores[] = "Debe seleccionar una fotografía válida para el aspirante.";
}
?>

<main class="container my-5">
    <section class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            
            <?php if (!empty($errores)): ?>
                <div class="alert alert-danger shadow-sm rounded-3">
                    <h4 class="alert-heading h5 fw-bold">No se pudo procesar el registro:</h4>
                    <ul class="mb-0 ps-3">
                        <?php foreach ($errores as $error): ?>
                            <li><?php echo $error; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="text-center mt-3">
                    <a href="index.php" class="btn btn-outline-secondary">Regresar al Formulario</a>
                </div>

            <?php else: ?>
                <div class="card shadow-sm border-0 rounded-3">
                    <div class="card-header bg-success text-white text-center py-3">
                        <h3 class="h5 mb-0 fw-bold">¡Registro de Aspirante Exitoso!</h3>
                    </div>
                    <div class="card-body p-4 text-center">
                        
                        <?php if ($rutaImagenServidor): ?>
                            <div class="mb-4">
                                <img src="<?php echo $rutaImagenServidor; ?>" alt="Foto del Aspirante" class="img-thumbnail rounded-circle shadow-sm" style="width: 150px; height: 150px; object-fit: cover;">
                            </div>
                        <?php endif; ?>

                        <ul class="list-group list-group-flush text-start mb-4">
                            <li class="list-group-item"><strong>Nombre Completo:</strong> <?php echo $nombre . ' ' . $apellido; ?></li>
                            <li class="list-group-item"><strong>Identificación:</strong> <?php echo $identificacion; ?></li>
                            <li class="list-group-item"><strong>Fecha de Nacimiento:</strong> <?php echo date('d/m/Y', strtotime($fechaNacimiento)); ?></li>
                            <li class="list-group-item"><strong>Edad:</strong> <?php echo $edad; ?> años</li>
                            <li class="list-group-item"><strong>Sexo:</strong> <?php echo $sexoLimpio; ?></li>
                            <li class="list-group-item"><strong>Archivo Guardado:</strong> <code><?php echo basename($rutaImagenServidor); ?></code></li>
                        </ul>

                        <a href="index.php" class="btn btn-primary w-100">Registrar Nuevo Aspirante</a>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>