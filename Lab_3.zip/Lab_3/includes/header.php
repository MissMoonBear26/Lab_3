<?php
$paginaActual = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Admisión de la UTP</title>
    
    <meta name="description" content="Sistema de admisión de datos para aspirantes">
    <meta name="author" content="Universidad Tecnológica de Panamá / FISC">
    <meta name="robots" content="noindex, nofollow">
    <meta name="theme-color" content="#D87093">
    
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Estilos Personalizados Rosado / Crema -->
    <link rel="stylesheet" href="css/custom.css">
</head>
<body class="d-flex flex-column min-vh-100">

<header>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">PortalU - UTP</a>
        </div>
    </nav>

    <div class="breadcrumb-container border-bottom py-2">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 small">
                    <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none">Inicio</a></li>
                    
                    <?php if ($paginaActual == 'procesar.php'): ?>
                        <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none">Registro</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Procesando Datos</li>
                    <?php else: ?>
                        <li class="breadcrumb-item active" aria-current="page">Registro de Aspirante</li>
                    <?php endif; ?>
                </ol>
            </nav>
        </div>
    </div>
</header>