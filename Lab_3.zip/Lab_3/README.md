<div align="center">

# 🧪 Laboratorio #3 - Desarrollo Web

![PHP](https://img.shields.io/badge/PHP-777BB4?style=for-the-badge&logo=php&logoColor=white)
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![XAMPP](https://img.shields.io/badge/XAMPP-FB7A24?style=for-the-badge&logo=xampp&logoColor=white)
![Git](https://img.shields.io/badge/GIT-F05032?style=for-the-badge&logo=git&logoColor=white)

---

### 👤 Datos del Estudiante
**Nombre:** Nohelis Castro  
**Proyecto:** Lab_3  

</div>

---

## 📌 Descripción del Proyecto

Este laboratorio consiste en una aplicación web desarrollada en **PHP**, diseñada para gestionar la carga, almacenamiento y procesamiento de archivos en un servidor local Apache (XAMPP).

---

## 📁 Estructura del Proyecto

```text
Lab_3/
├── 📁 css/              # Estilos visuales de la aplicación
├── 📁 includes/         # Modulos y funciones reutilizables
├── 📁 uploader_files/   # Scripts de gestión para subida de archivos
├── 📁 uploaded_files/   # Directorio de almacenamiento de archivos cargados
├── 📄 index.php         # Interfaz principal de la aplicación
└── 📄 procesar.php      # Lógica backend para el procesamiento de datos
```

---

## 🚀 Requisitos e Instalación

### 1. Prerrequisitos
* Tener instalado un servidor local como **[XAMPP](https://www.apachefriends.org/)**.
* Servidor Web **Apache** activo.

### 2. Pasos para ejecutar
1. Clonar o guardar esta carpeta dentro del directorio local de XAMPP:
   ```bash
   C:\xampp\htdocs\Practica\Lab_3
   ```
2. Iniciar el servicio de Apache en el panel de control de XAMPP.
3. Abrir el navegador e ingresar a la dirección:
   ```http
   http://localhost/Practica/Lab_3/index.php
   ```

---

## 🛠️ Tecnologías Utilizadas

* **PHP** - Lenguaje backend para el procesamiento de datos.
* **HTML5 & CSS3** - Estructura y diseño visual de la interfaz.
* **XAMPP / Apache** - Servidor web local.

---

<div align="center">

Desarrollado por **Nohelis Castro**

</div>